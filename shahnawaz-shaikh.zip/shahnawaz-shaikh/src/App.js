import React, {useState} from 'react';
import Styles from './App.module.scss';
import { Button, Heading, Input, Label, SelectGroup, SelectItem, Text } from './components';

function App() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({
    email: '',
    password: '',
  });

  const handleLogin = (e) => {
    e.preventDefault();
    const emailError = !validateEmail(email) ? 'Please add valid email address' : '';
    const passwordError = !validatePassword(password) ? 'Password must have a numeric value' : '';

    setErrors({
      email: emailError,
      password: passwordError,
    });

    if (!emailError && !passwordError) {
      console.log('Login successful!');
      setEmail('');
      setPassword('');
      setErrors({
        email: '',
        password: '',
      });
    }
  };

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validatePassword = (password) => {
    const numericRegex = /\d/;
    return numericRegex.test(password);
  };

  return (
    <div className={Styles.app}>
      <div className={Styles.wrapper}>
        <div className={Styles.formSection}>
          <div className={Styles.leftSection}>
            <Heading headingText={'Sample heading'} headingType={'h1'} color={'white'} /> 
            <Text variant={'mlg'} color={'white'}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum distinctio incidunt quae voluptas tempore dolorem, autem officia libero soluta.</Text>
          </div>
          <div className={Styles.rightSection}>
            <Heading headingText={'Create an account'} headingType={'h3'} color={'black'} />
            <form onSubmit={handleLogin}>
              <div className={Styles.mt30}>
                <Label variant={'md'} strong={'bold'}>Enter  your email</Label>
                <Input 
                  type={'text'} 
                  value={email}
                  className={errors.email ? Styles.errorBorder : ""}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              {errors.email && <Text className={Styles.error}>{errors.email}</Text>}
              <div className={Styles.mt30}>
                <Label variant={'md'} strong={'bold'}>Date of birth <Text variant={'sm'}>(Optional)</Text> </Label>
                <div className={`${Styles.dob}`}>
                  <div>
                    <Label variant={'sm'} color={'gray'}>Date</Label>
                    <Input type={'number'} />
                  </div>
                  <div>
                    <Label variant={'sm'} color={'gray'}>Month</Label>
                    <SelectGroup>
                      <SelectItem>January</SelectItem>
                      <SelectItem>February</SelectItem>
                      <SelectItem>March</SelectItem>
                      <SelectItem>April</SelectItem>
                      <SelectItem>May</SelectItem>
                      <SelectItem>June</SelectItem>
                      <SelectItem>July</SelectItem>
                      <SelectItem>August</SelectItem>
                      <SelectItem>September</SelectItem>
                      <SelectItem>October</SelectItem>
                      <SelectItem>November</SelectItem>
                      <SelectItem>December</SelectItem>
                    </SelectGroup>
                  </div>
                  <div>
                    <Label variant={'sm'} color={'gray'}>Year</Label>
                    <SelectGroup>
                      <SelectItem>2005</SelectItem>
                      <SelectItem>2004</SelectItem>
                      <SelectItem>2003</SelectItem>
                      <SelectItem>2002</SelectItem>
                      <SelectItem>2001</SelectItem>
                      <SelectItem>2000</SelectItem>
                      <SelectItem>1999</SelectItem>
                      <SelectItem>1998</SelectItem>
                      <SelectItem>1997</SelectItem>
                      <SelectItem>1996</SelectItem>
                      <SelectItem>1995</SelectItem>
                      <SelectItem>1994</SelectItem>
                      <SelectItem>1993</SelectItem>
                      <SelectItem>1992</SelectItem>
                      <SelectItem>1991</SelectItem>
                      <SelectItem>1990</SelectItem>
                    </SelectGroup>
                  </div>
                </div>
              </div>
              <div className={Styles.mt30}>
                <Label variant={'md'} strong={'bold'}>Choose a strong password</Label>
                <Input 
                  type={'password'} 
                  value={password}
                  className={errors.password ? Styles.errorBorder : ""}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              {errors.password && <Text className={Styles.error}>{errors.password}</Text>}
              <div className={Styles.mt30}>
                <Label variant={'md'} strong={'bold'}>Are you an agency or individual?</Label>
                <div className={`${Styles.dFlex} ${Styles.category}`}>
                  <Input 
                    type={'radio'} 
                    name={'category'}
                    id={'Individual'}
                    checked={true}
                  />
                  <Label htmlFor={'Individual'}>Individual</Label>
                  <Input 
                    type={'radio'} 
                    name={'category'}
                    id={'Agency'}
                    className={Styles.agency}
                  />
                  <Label htmlFor={'Agency'}>Agency</Label>
                </div>
              </div>
              
              <div className={Styles.mt30}>
                <Button type={'submit'} variant={'primary'}>Submit</Button>
              </div>              
            </form>
          </div>
        </div>
        <div className={Styles.note}>
          <Text variant={'mlg'} color={'black'}>Image source for sidebar image - https://unsplash.com/photos/arwTpnIUHdM</Text>
        </div>
      </div> 
    </div>
  );
}

export default App;
