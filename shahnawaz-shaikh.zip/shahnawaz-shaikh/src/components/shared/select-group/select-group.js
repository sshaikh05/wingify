import React from 'react'
import PropTypes from 'prop-types'

/**
 * Render SelectGroup
 * @param {node} children
 * @param {string} className
 * @returns node
 */

const SelectGroup = ({ children, className }) => {
  return (
    <select className={[className]}>{children}</select>
  )
}

SelectGroup.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
}

export default SelectGroup
