import React from 'react'
import PropTypes from 'prop-types'

/**
 * Render SelectItem
 * @param {any} children
 * @param {string} className
 * @returns node
 */

const SelectItem = ({ children, className }) => {
  return (
    <option className={[className]}>
      {children}
    </option>
  )
}

SelectItem.propTypes = {
  children: PropTypes.string,
  className: PropTypes.string
}

export default SelectItem
